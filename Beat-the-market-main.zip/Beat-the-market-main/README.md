# Beat-the-market
Deep learning project carried out to predict stock price trends as part of my studies in Reykjavik
